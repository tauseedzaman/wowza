<div class="row">
    <div class="col">
        <h2>Stream Name Groups</h2>
        <button class="btn btn-info" type="button" >Add Stream Name Groups</button>
    </div>
    <div class="col">
        <table class="table table-light">
            <thead class="thead-dark">
                <tr>
                    <th>Name</th>
                    <th>Streem Name</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Name</td>
                    <td>Streem Name</td>
                    <td>
                        <div class="btn-group" role="group" aria-label="Button group">
                            <button class="btn btn-primary" type="button">Edit</button>
                            <button class="btn btn-danger" type="button">Delete</button>
                        </div>
                    </td>
                </tr>
            </tbody>

        </table>
    </div>
</div>
