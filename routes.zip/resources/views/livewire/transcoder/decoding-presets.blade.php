<div class="row">
    <div class="col">
        <h4>Description</h4>
        <p>something</p>

        <h4>Decoder Implementation</h4>
        <p>something</p>


        <h4>Source Options</h4>
        <p>something</p>


        <hr>

        <h4>Overlay Images</h4>
        <p>some imags here</p>
    </div>
</div>
