<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class streamFilesController extends Controller
{
    //
}
