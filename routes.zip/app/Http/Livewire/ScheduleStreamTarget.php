<?php

namespace App\Http\Livewire;

use Livewire\Component;

class ScheduleStreamTarget extends Component
{
    public function render()
    {
        return view('livewire.schedule-stream-target');
    }
}
