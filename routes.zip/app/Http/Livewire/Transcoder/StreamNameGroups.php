<?php

namespace App\Http\Livewire\Transcoder;

use Livewire\Component;

class StreamNameGroups extends Component
{
    public function render()
    {
        return view('livewire.transcoder.stream-name-groups');
    }
}
