<?php

namespace App\Http\Livewire\Transcoder;

use Livewire\Component;

class DecodingPresets extends Component
{
    public function render()
    {
        return view('livewire.transcoder.decoding-presets');
    }
}
